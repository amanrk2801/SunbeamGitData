package com.sunbeam;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.transaction.annotation.Transactional;

import com.sunbeam.daos.PizzaItemDao;
import com.sunbeam.entities.PizzaItem;
import com.sunbeam.services.PizzaMenuService;

@SpringBootTest
class PizzaMenuServiceTests {
	@Autowired
	private PizzaMenuService menuService;
	@MockBean
	private PizzaItemDao itemDao;
	@Transactional
	@Test
	void testFindAllItems() {
		List<PizzaItem> list = menuService.findAllItems();
		for (PizzaItem item : list) {
			System.out.println("**" + item);
			item.getPriceList().forEach(System.out::println);
		}
		assertThat(list).isNotEmpty();
	}
	@Test
	void testFindItemTypes() {
		List<String> mockResult = new ArrayList<>();
		mockResult.add("Veg");
		mockResult.add("NonVeg");
		when(itemDao.findMenuTypes()).thenReturn(mockResult);
		
		List<String> list = menuService.findAllItemTypes();
		System.out.println("Item Types: " + list);
		assertEquals(2, list.size());
	}
}
