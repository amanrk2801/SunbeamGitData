package com.sunbeam;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;

@AutoConfigureMockMvc
@SpringBootTest
class AdminRestControllerTests {
	@Autowired
	private MockMvc mvc;
	
	@Test
	void testAdminHello() throws Exception {
		String testToken = "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiIxIiwiaWF0IjoxNzUzMjYxMjU5LCJleHAiOjE3NTMyOTcyNTksInJvbGUiOiJST0xFX0FETUlOIn0.tMV4t68hYuDX-l8afm3vEXdT59PRxLd3GK6YpXgXFig";
		mvc.perform(get("/admin/hello")
          .header("Authorization", "Bearer " + testToken))
          .andExpect(status().isOk())
          .andExpect(content().string("Hello"));
	}
}
