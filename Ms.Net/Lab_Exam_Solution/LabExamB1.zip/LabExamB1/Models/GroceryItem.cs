﻿
using LabExamB1.Helpers;
using System.ComponentModel.DataAnnotations;

namespace LabExamB1.Models
{
     public class GroceryItem
     {

        [Key]
        public int Id { get; set; }

        [Required]
        [StringLength(50, MinimumLength = 3)]
        public string ItemName { get; set; }

        [Required]
        [CategoryValidation(ErrorMessage = "Category must be one of: Grains, Dairy, Beverages, or Snacks.")]
        public string Category { get; set; }

        [Range(0, int.MaxValue, ErrorMessage = "Quantity must be non-negative.")]
        public int Quantity { get; set; }

        [Range(0.01, 1000.00, ErrorMessage = "Price must be between 0.01 and 1000.00.")]
        public double Price { get; set; }
    }
    }
