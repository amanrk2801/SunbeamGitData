﻿using System.ComponentModel.DataAnnotations;

namespace LabExamB1.Helpers
{
    public class CategoryValidationAttribute : ValidationAttribute
    {
        private readonly string[] categories = { "Grains", "Dairy", "Beverages", "Snacks" };

        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            if (value != null)
            {
                string category = value.ToString();
                if (categories.Contains(category, StringComparer.OrdinalIgnoreCase))
                {
                    return ValidationResult.Success;
                }
            }
            return new ValidationResult(ErrorMessage);
        }
    }
}

