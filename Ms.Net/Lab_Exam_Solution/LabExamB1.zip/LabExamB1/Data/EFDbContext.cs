﻿using System.Collections.Generic;
using LabExamB1.Models;
using Microsoft.EntityFrameworkCore;


namespace LabExamB1.Data
{
    public class EFDbContext:DbContext
    {
        

        
            public EFDbContext(DbContextOptions options) : base(options) { }

            public DbSet<GroceryItem> Groceries { get; set; }
        }
    }

