﻿

using LabExamB1.Data;
using LabExamB1.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace LabExamB1.Controllers
{
    public class HomeController : Controller
    {
        
           private EFDbContext db = null;

        public HomeController(EFDbContext _db)
        {
            db = _db;
        }
        public IActionResult Index()
        {
            List<GroceryItem> Groceries =  db.Groceries.ToList();

            return View("Index",Groceries);
        }

        

       

        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(GroceryItem groceryItem)
        {
            if (ModelState.IsValid)
            {
                db.Groceries.Add(groceryItem);
                db.SaveChanges();
                return Redirect("/Home/Index");
            }
            else
            {

                return View(groceryItem);
            }
        }
        


        public IActionResult Search(string categoryName)
        {

            var result = new List<GroceryItem>();
            var allItems = db.Groceries.ToList(); 

            foreach (var item in allItems)
            {
                Console.WriteLine(item.Category);
                if (!string.IsNullOrEmpty(categoryName) && item.Category.ToLower() == categoryName.ToLower())
                {
                    result.Add(item);
                }
            }

            return View("Index", result);
        }

        public IActionResult Edit(int id)
        {
            GroceryItem GroceryItem = db.Groceries.Find(id);
            return View(GroceryItem);
        }

        public IActionResult Delete(int id)
        {
            GroceryItem GroceryItem = db.Groceries.Find(id);
            db.Groceries.Remove(GroceryItem);
            db.SaveChanges();

            return View(GroceryItem);
        }

       
        public IActionResult AfterEdit(GroceryItem GroceryItemUpdated)
        {
            GroceryItem GroceryItem = db.Groceries.Find(GroceryItemUpdated.Id);
            GroceryItem.ItemName = GroceryItemUpdated.ItemName;
            GroceryItem.Price = GroceryItemUpdated.Price;
            GroceryItem.Quantity = GroceryItemUpdated.Quantity;
            db.SaveChanges();

            return Redirect("/Home/Index");
        }


    }
}
