﻿using System.ComponentModel.DataAnnotations;

namespace LabExamB2.Helper
{
    public class NotFutureDateAttribute : ValidationAttribute
        {
            protected override ValidationResult IsValid(object value, ValidationContext validationContext)
            {
                if (value is DateTime date && date <= DateTime.Today)
                    return ValidationResult.Success;

                return new ValidationResult(ErrorMessage);
            }
        }
    }


