﻿using System.ComponentModel.DataAnnotations;

namespace LabExamB2.Helper
{
    public class ValidDepartmentAttribute : ValidationAttribute
        {
            private static readonly string[] Departments = { "Cardiology", "Neurology", "Pediatrics", "Orthopedics" };

            protected override ValidationResult IsValid(object value, ValidationContext validationContext)
            {
                if (value != null && Departments.Contains(value.ToString(), StringComparer.OrdinalIgnoreCase))
                {
                    return ValidationResult.Success;
                }

                return new ValidationResult(ErrorMessage);
            }
        }
    }


