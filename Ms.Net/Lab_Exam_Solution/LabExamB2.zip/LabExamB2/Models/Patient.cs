﻿using System;
using System.ComponentModel.DataAnnotations;
using LabExamB2.Helper;

namespace LabExamB2.Models{
    public class Patient
    {

           [Key]
            public int Id { get; set; }

            [Required]
            [StringLength(50, MinimumLength = 3)]
            public string Name { get; set; }

            [Required]
            [ValidDepartment(ErrorMessage = "Department must be one of: Cardiology, Neurology, Pediatrics, Orthopedics.")]
            public string Department { get; set; }

            [Range(0, 120)]
            public int Age { get; set; }

            [NotFutureDate(ErrorMessage = "Admission Date cannot be in the future.")]
            public DateTime AdmissionDate { get; set; }
        }
    }


