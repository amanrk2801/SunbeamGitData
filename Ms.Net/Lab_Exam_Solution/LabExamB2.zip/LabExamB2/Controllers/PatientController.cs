﻿using LabExamB2.Data;
using LabExamB2.Models;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using System;

namespace LabExamB2.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
   
    public class PatientController : ControllerBase
    {
        private readonly PatientDbContext db ;
        public PatientController(PatientDbContext _db)
        {
            db = _db;
        }

        [HttpGet]
        public IEnumerable<Patient> Get()
        {
            return db.Patients.ToList();
        }

        [HttpGet("{id}")]
        public Patient Get(int id)
        {
            return db.Patients.Find(id);
        }

        [HttpPost]
        public IActionResult Post([FromBody] Patient patient)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.Patients.Add(patient);
            db.SaveChanges();

            return Ok(new { message = "Patient added", data = patient });
        }

        [HttpPut("{id}")]
        public IActionResult Put(int id, [FromBody] Patient updated)
        {
            Patient patient = db.Patients.Find(id);
            if (patient == null)
                return NotFound(new { message = "Patient not found" });

            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            patient.Name = updated.Name;
            patient.Department = updated.Department;
            patient.Age = updated.Age;
            patient.AdmissionDate = updated.AdmissionDate;

            db.SaveChanges();

            return Ok(new { message = "Patient updated", data = patient });
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            Patient patient = db.Patients.Find(id);
            if (patient == null)
                return NotFound(new { message = "Patient not found" });

            db.Patients.Remove(patient);
            db.SaveChanges();

            return Ok(new { message = "Patient deleted" });
        }

        [HttpGet("by-department/{department}")]
        public IActionResult GetByDepartment(string department)
        {
            List<Patient> results = new List<Patient>();
            foreach (var p in db.Patients)
            {
                if (p.Department.Equals(department))
                {
                    results.Add(p);
                }
            }

            if (results.Count == 0)
                return NotFound(new { message = "No patients found in this department" });

            return Ok(new { message = "Patients found", data = results });
        }
    }
}
