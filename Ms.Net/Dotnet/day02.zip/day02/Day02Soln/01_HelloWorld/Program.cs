﻿
Console.WriteLine("Hello, World!");
