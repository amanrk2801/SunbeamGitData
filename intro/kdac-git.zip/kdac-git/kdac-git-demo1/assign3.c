#include <stdio.h>

int main()
{
  int num1, num2, res;
  printf("Enter two numbers: ");
  scanf("%d%d", &num1, &num2);
  res = num1 * num2;
  printf("Multiplication Result: %d\n", res);
  return 0;
}