#include <stdio.h>

int main()
{
  int num1, num2, res;
  printf("Enter two numbers: ");
  scanf("%d%d", &num1, &num2);
  res = num1 + num2;
  printf("Addition Result: %d\n", res);
  res = num1 - num2;
  printf("Subtraction Result: %d\n", res);
  return 0;
}