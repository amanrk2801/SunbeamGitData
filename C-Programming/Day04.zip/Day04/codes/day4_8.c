// nested structure

#include<stdio.h>

struct student
{
    int reg_id;
    struct                 // anonymous structure
    {
        char f_name[10];
        char m_name[10];
        char l_name[10];
    }name;   // name is a variable of the nested structure
    int age;
};

int main()
{
    struct student s1;

    printf("Enter the student reg id and age :");
    scanf("%d%d",&s1.reg_id,&s1.age);

    printf("Enter the full name : ");
    scanf("%s%s%s",&s1.name.f_name,&s1.name.m_name,&s1.name.l_name);

    printf("the student details :\n");
    printf("reg id = %d  name = %s  %s  %s  age = %d\n",s1.reg_id,s1.name.f_name,s1.name.m_name,s1.name.l_name,s1.age);
    return 0;
}