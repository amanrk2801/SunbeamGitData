// Passing structure to a function
#include<stdio.h>

struct date
{
    int dd;
    int mm;
    int yy;
};

void accept_date(struct date d1);
void print_date(struct date d1);
void accept_date_by_address(struct date *ptr);

int main()
{
    struct date d1;
   // accept_date(d1);
    accept_date_by_address(&d1);
    print_date(d1);
    return 0;
}

void accept_date(struct date d1)
{
    printf("Enter the date :");
    scanf("%d%d%d",&d1.dd,&d1.mm,&d1.yy);
}

void accept_date_by_address(struct date *ptr)
{
    printf("Enter the date :");
    scanf("%d%d%d",&ptr->dd,&ptr->mm,&ptr->yy);
}

void print_date(struct date d1)
{
    printf("Date : %d - %d - %d\n",d1.dd,d1.mm,d1.yy);
}