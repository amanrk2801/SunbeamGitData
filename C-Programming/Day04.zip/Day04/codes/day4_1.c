// 2-D arrays

#include<stdio.h>
void accept_data(int arr3[2][3]);
void print_data(int arr3[2][3]);
int main()
{
    int arr[2][3] = {11,22,33,44,55,66};

    int arr1[3][3] = {10,20,30,40,50};// partial initialized

    int arr2[3][3] = {{1,2},{3,4,5},{6}};
    printf("arr[1][1] = %d\n",arr[1][1]);

    int arr3[2][3];

    int arr4[][3] = {1,2,3,4,5};
    /*
        1   2   3
        4   5   0
    */
    accept_data(arr3);
    print_data(arr3);
    return 0;
}

void accept_data(int arr3[2][3]) // 100
{
    printf("enter the array elements :");

    for(int i =0; i<2; i++) // rows
    {
        for(int j = 0; j<3; j++) // columns
        {
            scanf("%d",&arr3[i][j]);
        }
    }
}


void print_data(int arr3[2][3])
{
    printf("The array elements are :\n");

    for(int i =0; i<2; i++)
    {
        for(int j = 0; j<3; j++)
        {
            printf("%4d",arr3[i][j]);
        }
        printf("\n");
    }
}
