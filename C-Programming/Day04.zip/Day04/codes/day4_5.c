// array of structure

#include<stdio.h>

struct employee
{
    int emp_id;
    char name[20];
    int age;
};

int main()
{
    struct employee emp[3];

    

    printf("Enter the info for 3 employees :");

    for(int i =0; i<3; i++)
    {
        printf("enter the emp id :");
        scanf("%d",&emp[i].emp_id);
        printf("Enter the name :");
        scanf("%s",&emp[i].name);
        printf("enter the age :");
        scanf("%d",&emp[i].age);
    }

    printf("The employee details are :\n");

    for(int i =0; i<3; i++)
    {
        printf("Emp id = %d  name = %s  age = %d\n",emp[i].emp_id,emp[i].name,emp[i].age);
    }

    //_________________________________________________

    struct employee e1 = {1001,"Nisha",35};
    struct employee *ptr = &e1;

    printf("Emp details using e1 : %d  %s  %d\n",e1.emp_id,e1.name,e1.age);
    printf("Emp Details using ptr : %d  %s  %d\n",ptr->emp_id,ptr->name,ptr->age);
    return 0;
}