//File Handling : fprintf, fscanf

#include<stdio.h>
#include<stdlib.h>

int main()
{
    FILE *fptr = fopen("sunbeam.txt","w");

    if(fptr == NULL)
    {
        printf("Error while opening the FILE !");
        return 1; // return failure
    }

    char name[20];
    int marks;


    for(int i =1; i<=3; i++)
    {
        printf("Enter the name and marks :");
        scanf("%s%d",&name,&marks);
        fprintf(fptr,"%s  %d\n",name,marks);
    }

    printf("Data inserted in file !\n");
    fclose(fptr);

    printf("Reading the data from the file !\n");
    fptr = fopen("sunbeam.txt","r");

   while(fscanf(fptr,"%s%d",&name,&marks) != EOF)
   {
         printf("Name = %s  marks = %d\n",name,marks);
   }
    fclose(fptr);
    return 0; // return success
}