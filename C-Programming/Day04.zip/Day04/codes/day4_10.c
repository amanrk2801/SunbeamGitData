// File handling : fputs, fgets

#include<stdio.h>

int main()
{
    FILE *fptr = fopen("sun.txt","w");
    char str[100];

    printf("Enter the data !\n");
    gets(str); // gets to get the string from the console

    fputs(str,fptr);

    printf("Data inserted into the file !\n");
    fclose(fptr);

    printf("REading the data from the file !\n");
    fptr = fopen("sun.txt","r");

    fgets(str,sizeof(str),fptr);

    printf("Data read from the file is :\n");
    printf("%s",str);

    fclose(fptr);
    return 0;
}