// structure : user defined datatype
// used to store dissimilar data elements

#include<stdio.h>

struct student
{
    int reg_id;
    char name[20];
    float marks;
};


int main()
{
    struct student s1 = {12345,"Nisha",95};

    struct student s2;
    printf("Enter the reg is, name and marks :");
    scanf("%d%s%f",&s2.reg_id,&s2.name,&s2.marks);

    printf("The Details of s1 student : \n ");
    printf("%d  %s  %.2f\n",s1.reg_id,s1.name,s1.marks);

    printf("The Details of s2 student : \n ");
    printf("%d  %s  %.2f\n",s2.reg_id,s2.name,s2.marks);
    return 0;
}