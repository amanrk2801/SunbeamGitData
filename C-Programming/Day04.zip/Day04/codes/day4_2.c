// Dynamic Memory Allocation
// Malloc

#include<stdio.h>
#include<stdlib.h>

int main()
{
    int num1; // compile time -> 4 bytes
    int arr[3]; // compile time -> 12 bytes

   int *ptr =(int*) malloc(sizeof(int));
    // allocates the memory at run time in the heap section

    *ptr = 25;

    printf("*ptr = %d\n",*ptr);

    free(ptr); // free(500); to avoid memory wastage

    // here ptr is a dangling pointer : pointing to the memory
    // which does not exist
     ptr = NULL; // to avoid dangling pointer

     ptr = (int *) malloc (sizeof(int)*5); // creating an array at runtime
    ptr[0] = 10;
    ptr[1] = 20;
    ptr[2] = 30;

    free(ptr);
    ptr = NULL;
    
    return 0;
}