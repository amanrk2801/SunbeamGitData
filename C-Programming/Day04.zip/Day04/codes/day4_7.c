// using 1 structure into another

#include<stdio.h>
struct date
{
    int dd;
    int mm;
    int yy;
};

struct employee
{
    int emp_id;
    char name[20];
    struct date DOB; // DOB is the variable of struct date
    // it is also a field of struct employee
    struct date DOJ;
};

int main()
{
    struct employee e1;

    printf("enter the emp id and name :");
    scanf("%d%s",&e1.emp_id,&e1.name);

    printf("Enter the date of birth :");
    scanf("%d%d%d",&e1.DOB.dd,&e1.DOB.mm,&e1.DOB.yy);

    printf("enter the date of Joining :");
    scanf("%d%d%d",&e1.DOJ.dd,&e1.DOJ.mm,&e1.DOJ.yy);

    printf("The employee Details are :");
    printf("emp id : %d  name : %s\n",e1.emp_id,e1.name);

    printf("DOB : %d - %d - %d\n",e1.DOB.dd,e1.DOB.mm,e1.DOB.yy);

    printf("DOJ : %d - %d - %d\n",e1.DOJ.dd,e1.DOJ.mm,e1.DOJ.yy);
    return 0;
}