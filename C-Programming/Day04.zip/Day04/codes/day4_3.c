// calloc , realloc

#include<stdio.h>
#include<stdlib.h>

int main()
{
    int *ptr =(int*) calloc(sizeof(int),3);
    // default value in memory using calloc is 0

    printf("Enter the 3 values :");

    for(int i =0; i<3; i++)
    {
        scanf("%d",&ptr[i]);
    }

    printf("The values are :\n");
    for(int i =0; i<3; i++)
    {
        printf("%4d",ptr[i]);
    }

    printf("\n After Realloc :\n");
     ptr = (int *)realloc(ptr,sizeof(int)*5);

     ptr[3] = 25;
     ptr[4] = 50;

     for(int i =0; i<5; i++)
    {
        printf("%4d",ptr[i]);
    }

    free(ptr);
     ptr = NULL;

    return 0;
}