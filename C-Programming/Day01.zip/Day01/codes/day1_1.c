// Hello Program

#include<stdio.h> // standard input output header file

// entry point function
/*
int main() // User Defined function
{
    printf("Hello Students ! Welcome to Sunbeam !");
    return 0; // Exit status : Success
}
*/

void main() // User Defined function
{
    printf("Hello Students ! Welcome to Sunbeam !");
}



/*
return_type  function_name (input parameters)
int           main()


*/