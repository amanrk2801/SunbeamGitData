// Arrays : declaration and printing

#include<stdio.h>

int main()
{
    int arr[5]; // garbage values

    arr[0] = 10;
    arr[1] = 20;
    arr[2] = 30;

    printf("arr[2] = %d\n",arr[2]);
    printf("arr[3] = %d\n",arr[3]); // garbage

    int arr1[3] = {11,22,33};

    int arr2[5] = {1,2,3}; // partial initialization

    printf("arr2[1] = %d\n",arr2[1]);
    printf("arr2[3] = %d\n",arr2[3]);// 0 

    int arr3[5] = {11,22,33,44,55};

    for(int i = 0; i<5; i++)
    {
        printf("%4d",arr3[i]);// 11  22 33
    }
    return 0;
}