// size of variables and size of pointer variables

#include<stdio.h>

int main()
{
    int num1 = 10; // 4 bytes
    char ch = 'Z'; // 1 byte
    float f_num = 1.2; // 4 bytes
    double d_num = 3.4; // 8 bytes

    int *ptr = &num1;
    char *c_ptr = &ch;
    float *f_ptr = &f_num;
    double *d_ptr = &d_num;

    printf("size of num1 = %d\n",sizeof(num1));
    printf("size of char = %d\n",sizeof(char));
    printf("size of float = %d\n",sizeof(float));
    printf("size of d_num = %d\n",sizeof(d_num));


    printf("size of pointer ptr = %d\n",sizeof(ptr));
    printf("size of pointer c_ptr = %d\n",sizeof(c_ptr));
    printf("size of pointer f_ptr = %d\n",sizeof(f_ptr));
    printf("size of pointer d_ptr = %d\n",sizeof(d_ptr));


    return 0;
}