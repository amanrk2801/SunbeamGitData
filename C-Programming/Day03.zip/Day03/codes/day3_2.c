// pass by value and address

#include<stdio.h>

void swap(int n1, int n2);
void swap_by_address(int *ptr1, int *ptr2);
int main()
{
    int num1 = 25, num2 = 50;

    printf("Before swap : num1 = %d  num2 = %d\n",num1,num2); // 25 50
    swap(num1,num2); // 25 50
    printf("After swap : num1 = %d  num2 = %d\n",num1,num2);// 25 50


    printf("\nSwap By Address :\n");
    printf("Before swap : num1 = %d  num2 = %d\n",num1,num2);
    swap_by_address(&num1,&num2); // 100 200
    printf("After swap : num1 = %d  num2 = %d\n",num1,num2);
    return 0;
}

void swap(int n1, int n2)
{
    int temp;
    temp = n1;
    n1 = n2;
    n2 = temp;
}

void swap_by_address(int *ptr1, int *ptr2) //100 200
{
    int temp;
    temp = *ptr1;
    *ptr1 = *ptr2;
    *ptr2 = temp;
}

