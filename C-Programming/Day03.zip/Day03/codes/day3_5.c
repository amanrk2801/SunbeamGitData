// char arrays

#include<stdio.h>

int main()
{
    char str1[5] = {'A','B','C','D','E'}; // char array

    char str2[5] = {'A','B','C','D','\0'}; // string

    char str3[5] = {'S','U','N'}; // partial initialization
    // string

    char str4[4] = "Info"; // char array

    char str5[5] = "Info"; // string

    char str6[] = {'P','U','N','E'}; // char array

    char str7[] = "Sunbeam"; // string 

    printf("%s\n",str7);

    printf("Char array :");
    for(int i =0;i<5; i++)
    {
        printf("%c",str1[i]);
    }
    return 0;
}