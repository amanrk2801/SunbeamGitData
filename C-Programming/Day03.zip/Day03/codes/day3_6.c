// string functions : 
// strlen ,strcpy,strcmp, strchr, strstr, strrev, strcat, strupr, strlwr 

#include<stdio.h>
#include<string.h>
int main()
{
    char str1[] = "sunbeam";
    char str2[10];
    char ch = 'b';
    char str3[] = "eam";

    printf("str1 = %s\n",str1);
    printf("String length = %d\n",strlen(str1));
    strcpy(str2,str1);
    printf("str2 = %s\n",str2);

    int res = strcmp(str1,str2);// -1 , 0 , 1

    if(res == 0)
        printf("The strings are Equal !\n");
    else if( res > 0)
        printf("String 1 is greater !\n");
    else
        printf("String 2 is Greater !\n");


      char *ptr =  strchr(str1,ch);

      printf("char found at index = %d\n",ptr-str1);


     char *ptr1 = strstr(str1,str3);
     printf("sub string found at index %d\n", ptr1-str1);

     printf("reversed string : %s\n",strrev(str1)); // maebnus

    strcat(str1,str3);// maebnuseam

    printf("string = %s\n",str1); // maebnuseam
    return 0;
}