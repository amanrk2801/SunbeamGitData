// arrays in function

#include<stdio.h>
void accept_data(int arr[5]);
void print_data(int arr[5]);
int main()
{
    int arr[5]; // size of arr in main is 20 bytes

    accept_data(arr); // 100
    print_data(arr); // 100
    return 0;
}
// arrays are by default pass by address

void accept_data(int arr[5])// 100
{
    printf("Enter the 5 values for the array :");
// size of arr in accept_data function is 4 bytes(size of pointer)
    for(int i =0; i<5; i++)
    {
        scanf("%d",arr[i]);
    }   
}


void print_data(int arr[5])
{
    printf("The array values are :");
// size of arr here is also 4 bytes(size of pointer on 32 bit compiler)
    for(int i =0; i<5; i++)
    {
        printf("%4d",arr[i]);
    }
}