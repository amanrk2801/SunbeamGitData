const mysql = require('mysql2')

const pool = mysql.createPool({
    connectionLimit: 10,
    user: 'root',
    password: 'manager',
    database: 'car_showroom',
    port: 3306,
    host: 'localhost',

})

module.exports = 
    pool
