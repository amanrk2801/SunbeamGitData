const express = require('express')
const app = express()
const cors = require('cors');
const carRouter = require('./routes/car')
const path = require('path')
app.use(cors());

// Middleware to parse JSON bodies
app.use(express.json())

// Use the user router

app.use('/car', carRouter)

app.use('/images', express.static(path.join(__dirname, 'images')))

app.listen(4000, '0.0.0.0', () => {
    console.log('server started on port 4000')
})